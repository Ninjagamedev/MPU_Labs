package task3;

public class PHDAIDDD extends PHD {
    public PHDAIDDD(){
        this.setDuration(3);
        this.setCredit(30);
        this.setName("PhD in Artificial Intelligence Driven Drug Discovery");
    }
}
