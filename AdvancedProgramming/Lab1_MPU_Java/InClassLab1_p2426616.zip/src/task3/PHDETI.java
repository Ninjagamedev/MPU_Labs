package task3;

public class PHDETI extends PHD{
    public PHDETI(){
        this.setDuration(3);
        this.setCredit(30);
        this.setName("PhD in Educational Technology and Innovation");
    }
}
