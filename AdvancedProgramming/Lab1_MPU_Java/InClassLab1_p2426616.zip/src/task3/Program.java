package task3;

public abstract class Program {
    //Create the name variable which is a String that can only have the Value of bachelor, masters or phd
    private String grade;
    private String name;
    private int credit;
    private int duration;

    public Program(){}
    public String getGrade(){
        return grade;
    }

    public void setGrade(String grade){
        if (grade.equalsIgnoreCase("bachelor") || grade.equalsIgnoreCase("masters") || grade.equalsIgnoreCase("phd")) {
            this.grade = grade;
        }
        else {
            System.out.println("Invalid program name");
        }
    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public int getCredit(){
        return credit;
    }
    public void setCredit(int credit){
        this.credit = credit;
    }
    public int getDuration(){
        return duration;
    }
    public void setDuration(int duration){
        this.duration = duration;
    }
}
