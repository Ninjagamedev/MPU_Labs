package task3;

public class BachelorOfSIAI extends Bachelor{
    public BachelorOfSIAI(){
        super();
        this.setDuration(4);
        this.setCredit(126);
        this.setName("Bachelor of Science in Artificial Intelligence");
    }
}
