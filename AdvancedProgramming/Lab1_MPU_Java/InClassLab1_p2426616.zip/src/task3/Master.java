package task3;

public abstract class Master extends Program{
    public Master(){
        this.setGrade("Masters");
    }
}
