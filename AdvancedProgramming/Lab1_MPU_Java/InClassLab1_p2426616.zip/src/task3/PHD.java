package task3;

public abstract class PHD extends Program{
    public PHD(){
        this.setGrade("PHD");
    }
}
