package task3;

public class MasterSBDAIT extends Master{
    public MasterSBDAIT(){
        this.setDuration(2);
        this.setCredit(30);
        this.setName("Master of Science in Big Data and Internet of Things");
    }
}
