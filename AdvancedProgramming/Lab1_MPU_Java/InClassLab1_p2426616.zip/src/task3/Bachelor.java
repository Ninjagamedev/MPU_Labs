package task3;

public abstract class Bachelor extends Program{
    public Bachelor(){
        this.setGrade("Bachelor");
    }
}
