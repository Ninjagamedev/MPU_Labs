package task3;

public class Main {
    public static void main(String[] args) {
        Bachelor bachelorOfSIC = new BachelorOfSIC();
        System.out.println(bachelorOfSIC.getName());
        System.out.println(bachelorOfSIC.getDuration());
        System.out.println(bachelorOfSIC.getCredit());
        System.out.println(bachelorOfSIC.getGrade());

        Master master = new MasterSBDAIT();
        System.out.println(master.getGrade());
        System.out.println(master.getName());

        PHD phd = new PHDAIDDD();
        System.out.println(phd.getGrade());
        System.out.println(phd.getName());
    }
}
