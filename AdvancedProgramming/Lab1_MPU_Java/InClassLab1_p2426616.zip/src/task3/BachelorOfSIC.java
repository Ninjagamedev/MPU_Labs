package task3;

public class BachelorOfSIC extends Bachelor{
    public BachelorOfSIC(){
        super();
        this.setDuration(4);
        this.setCredit(126);
        this.setName("Bachelor of Science in Computing");
    }
}
