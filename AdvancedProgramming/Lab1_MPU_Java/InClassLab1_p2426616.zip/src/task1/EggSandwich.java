package task1;

public class EggSandwich {
    private double price;

    public EggSandwich(){
        price = 16.0;
    }

    public double getPrice() {
        return price;
    }
}
