package task1;

public class LemonTea {
    private double price;

    public LemonTea(){
        price = 17.0;
    }

    public double getPrice() {
        return price;
    }
}
