package task1;

public class PorkSandwich {
    private double price;

    public PorkSandwich(){
        price = 20.0;
    }

    public double getPrice() {
        return price;
    }
}
