package task1;

public class VeganSalad {
    private double price;

    public VeganSalad(){
        price = 41.0;
    }

    public double getPrice() {
        return price;
    }
}
