package task1;

public class CesarSalad {
    private double price;

    public CesarSalad(){
        price = 36.0;
    }

    public double getPrice() {
        return price;
    }
}
