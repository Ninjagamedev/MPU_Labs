package task1;

public class Coffee {
    private double price;

    public Coffee(){
        price = 19.0;
    }

    public double getPrice() {
        return price;
    }

}
