package task1;

public class Main {
public static void main(String[] args) {
    EggSandwich sandwich1 = new EggSandwich();
    PorkSandwich sandwich2 = new PorkSandwich();
    CesarSalad salad1 = new CesarSalad();
    VeganSalad salad2 = new VeganSalad();
    Coffee drink1 = new Coffee();
    MilkTea drink2 = new MilkTea();
    LemonTea drink3 = new LemonTea();
    System.out.println(sandwich1.getPrice());
    System.out.println(sandwich2.getPrice());
    System.out.println(salad1.getPrice());
    System.out.println(salad2.getPrice());
    System.out.println(drink1.getPrice());
    System.out.println(drink2.getPrice());
    System.out.println(drink3.getPrice());
}
}
