package task1;

public class MilkTea {
    private double price;

    public MilkTea(){
        price = 16.0;
    }

    public double getPrice() {
        return price;
    }
}
