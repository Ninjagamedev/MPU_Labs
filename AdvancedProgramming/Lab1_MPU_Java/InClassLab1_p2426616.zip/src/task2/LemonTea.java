package task2;

public class LemonTea extends Drink{
    public LemonTea(){
        price = 17.0;
        hotOrIced = "Iced";
    }
}
