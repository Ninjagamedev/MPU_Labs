package task2;

public abstract class Drink {
    protected double price;
    protected String hotOrIced;

    public Drink(){}

    public double getPrice() {
        return price;
    }

    public String getHotorIced() {
        return hotOrIced;
    }
}
