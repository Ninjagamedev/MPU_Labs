package task2;

public class MilkTea extends Drink{
    public MilkTea(){
        price = 16.0;
        hotOrIced = "Hot";
    }
}
