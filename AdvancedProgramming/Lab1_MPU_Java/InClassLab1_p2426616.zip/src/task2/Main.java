package task2;

public class Main {
    public static void main(String[] args) {
        Food sandwich1 = new EggSandwich();
        Food sandwich2 = new PorkSandwich();
        Food salad1 = new CesarSalad();
        Food salad2 = new VeganSalad();
        Drink drink1 = new Coffee();
        Drink drink2 = new MilkTea();
        Drink drink3 = new LemonTea();
        System.out.println(sandwich1.getPrice() + ", "
                + ((Sandwich)sandwich1).getUseEgg());
        System.out.println(sandwich2.getPrice() + ", "
                + ((Sandwich)sandwich2).getUseEgg());
        System.out.println("" + salad1.getPrice() + ", "
                + ((Salad)salad1).isVegan());
        System.out.println("" + salad2.getPrice() + ", "
                + ((Salad)salad2).isVegan());
        System.out.println(drink1.getPrice() + ", "
                + drink1.getHotorIced());
        System.out.println(drink2.getPrice() + ", "
                + drink2.getHotorIced());
        System.out.println(drink3.getPrice() + ", "
                + drink3.getHotorIced());
    }
}
