package task2;

public class Coffee extends Drink{
    public Coffee(){
        price = 19.0;
        hotOrIced = "Hot";
    }
}
