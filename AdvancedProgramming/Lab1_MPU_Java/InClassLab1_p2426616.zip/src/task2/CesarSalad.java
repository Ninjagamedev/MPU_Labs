package task2;

public class CesarSalad extends Salad{
    public CesarSalad(){
        price = 36.0;
        vegan = false;
    }
}
