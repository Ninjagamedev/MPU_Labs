package task2;

public class Sandwich extends Food{
    protected int useEgg;
    public Sandwich(){}
    public int getUseEgg(){
        return useEgg;
    }
}
