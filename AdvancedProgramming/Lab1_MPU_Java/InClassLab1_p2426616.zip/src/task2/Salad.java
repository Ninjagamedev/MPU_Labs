package task2;

public class Salad extends Food{
    protected boolean vegan;
    public Salad(){}
    public boolean isVegan(){
        return vegan;
    }
}
