package task2;

public abstract class Food {
    protected double price;
    public Food(){}
    public double getPrice() {
        return price;
    }
}
