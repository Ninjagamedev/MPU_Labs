package task2;

public class EggSandwich extends Sandwich{
    public EggSandwich(){
        price = 16.0;
        useEgg = 2;
    }
}
