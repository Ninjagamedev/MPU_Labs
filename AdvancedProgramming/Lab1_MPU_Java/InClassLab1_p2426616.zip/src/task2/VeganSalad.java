package task2;

public class VeganSalad extends Salad{
    public VeganSalad(){
        price = 41.0;
        vegan = true;
    }
}
