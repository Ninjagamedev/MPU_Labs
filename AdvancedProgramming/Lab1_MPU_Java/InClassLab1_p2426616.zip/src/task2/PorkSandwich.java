package task2;

public class PorkSandwich extends Sandwich{
    public PorkSandwich(){
        price = 20.0;
        useEgg = 0;
    }
}
